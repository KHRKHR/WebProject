package com.test.main.admin.productmanagement;

public class ProductManagementDTO {
	private String productseq;
	private String productname;
	private String category;
	private String price;
	private String totalstock;
	private String totalsalemoney;
	private String avgreview;
	private String inventory;
	private String salesstatus;
	
	
	public String getProductseq() {
		return productseq;
	}
	public void setProductseq(String productseq) {
		this.productseq = productseq;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getTotalstock() {
		return totalstock;
	}
	public void setTotalstock(String totalstock) {
		this.totalstock = totalstock;
	}
	public String getTotalsalemoney() {
		return totalsalemoney;
	}
	public void setTotalsalemoney(String totalsalemoney) {
		this.totalsalemoney = totalsalemoney;
	}
	public String getAvgreview() {
		return avgreview;
	}
	public void setAvgreview(String avgreview) {
		this.avgreview = avgreview;
	}
	public String getInventory() {
		return inventory;
	}
	public void setInventory(String inventory) {
		this.inventory = inventory;
	}
	public String getSalesstatus() {
		return salesstatus;
	}
	public void setSalesstatus(String salesstatus) {
		this.salesstatus = salesstatus;
	}
	
	
}
