package com.test.main.admin.membermanagement;

public class ManagementQaDTO {
	String qaseq;
	String qacategory;
	String qasubject;
	String qacontent;
	String qaanswer;
	String qadate;
	
	
	public String getQaseq() {
		return qaseq;
	}
	public void setQaseq(String qaseq) {
		this.qaseq = qaseq;
	}
	public String getQacategory() {
		return qacategory;
	}
	public void setQacategory(String qacategory) {
		this.qacategory = qacategory;
	}
	public String getQasubject() {
		return qasubject;
	}
	public void setQasubject(String qasubject) {
		this.qasubject = qasubject;
	}
	public String getQacontent() {
		return qacontent;
	}
	public void setQacontent(String qacontent) {
		this.qacontent = qacontent;
	}
	public String getQaanswer() {
		return qaanswer;
	}
	public void setQaanswer(String qaanswer) {
		this.qaanswer = qaanswer;
	}
	public String getQadate() {
		return qadate;
	}
	public void setQadate(String qadate) {
		this.qadate = qadate;
	}
	
}
